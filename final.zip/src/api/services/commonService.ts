/**
 * LOCAL DEV STUB — a generic Prisma-backed CRUD helper, matching the calling
 * shape used elsewhere in this checkout (getFromTable/getManyFromTable/
 * insertIntoTable/updateTable/updateManyInTable with a bare table-name
 * string). The real commonService.ts likely also handles legacy Kysely/raw
 * fallbacks; this version only does the Prisma path, which is all
 * authSessionService.ts and middleware/auth.ts's verifyRoleBasedAccess need.
 */
import prisma from "../../config/sqlServerClient";

function modelFor(tableName: string): any {
  const key = tableName.charAt(0).toLowerCase() + tableName.slice(1);
  const model = (prisma as any)[key];
  if (!model) {
    throw new Error(`commonService: no Prisma model found for table "${tableName}" (looked up as "${key}")`);
  }
  return model;
}

class CommonService {
  async getFromTable(tableName: string, where: Record<string, any>, options: Record<string, any> = {}) {
    return modelFor(tableName).findFirst({ where, ...options });
  }

  async getManyFromTable(tableName: string, where: Record<string, any>, options: Record<string, any> = {}) {
    return modelFor(tableName).findMany({ where, ...options });
  }

  async insertIntoTable(tableName: string, data: Record<string, any>) {
    return modelFor(tableName).create({ data });
  }

  async updateTable(tableName: string, where: Record<string, any>, data: Record<string, any>) {
    return modelFor(tableName).update({ where, data });
  }

  async updateManyInTable(tableName: string, where: Record<string, any>, data: Record<string, any>) {
    return modelFor(tableName).updateMany({ where, data });
  }
}

export default new CommonService();
