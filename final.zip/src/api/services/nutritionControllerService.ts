/**
 * Nutrition module service — ported from foodDR's V2 nutrition-client
 * endpoints, adapted to the *real* database schema.
 *
 * IMPORTANT: this file previously targeted a schema
 * (user_nutrition_profiles.age/height/weight-as-strings, a separate `users`
 * table, `weight_logs`, `meal_logs`, `plan_meal_slots` with an
 * `activity_level_id` FK into `nutrition_masters`) that does not exist in
 * the live database — it was a plausible-looking but fictional schema
 * carried over from the wider `wms` platform this checkout is a partial
 * export of. `npx prisma db pull` against the actual `nutrition_sandbox`
 * database (the same one foodDR's production backend-node service uses)
 * replaced prisma/schema.prisma with the 19 real tables — user identity and
 * profile live in one table, `user_nutrition_profiles` (string/UUID `id`,
 * `birth_year` not `age`, `height_cm`/`current_weight_kg` as numbers not
 * unit-tagged strings, `activity_level` as a plain string column, no
 * `nutrition_masters` FK for it); weight history lives in `daily_stats`
 * (`weight_kg`/`weight_lbs`/`weight_logged_at`, one row per user per day,
 * not a dedicated weight_logs table); meal logs live in `meals`; the plan's
 * meal schedule is a JSON blob (`meal_schedule_json`) on
 * `user_nutrition_plans`, not separate `plan_meal_slots` rows.
 *
 * `userId` is a **string** (the real `user_nutrition_profiles.id`) — every
 * signature below was changed from `number` to `string` accordingly; the
 * old `Number(req.body.authUserId)` cast in the controller would have
 * silently produced NaN for any real (non-numeric) user id.
 *
 * Health-critical constants (calorie floors, macro split, water target,
 * activity multipliers) are carried over unchanged from foodDR — see the
 * comments inline where each is used. The deterministic (non-AI) meal-slot
 * split is also unchanged by design: this checkout has no Gemini/AI wiring
 * for meal suggestions, so it never attempted to replicate foodDR's
 * AI-assisted plan generation, only the fixed-percentage fallback shape.
 */
import { randomUUID } from "crypto";
import momentTZ from "moment-timezone";
import AppError from "../core/error-handler";
import { ERROR_MESSAGE } from "../constants/index";
import prisma from "../../config/sqlServerClient";
import type {
  NutritionProfileReq,
  GetNutritionTimelineReq,
  GetWeightHistoryReq,
  JsonRecord,
} from "../interface/nutrition.interface";

// ── Health-critical constants (unchanged from foodDR) ───────────────────────
const CALORIE_FLOOR_FEMALE = 1200;
const CALORIE_FLOOR_MALE = 1500;
const DEFAULT_CARBS_PCT = 0.4;
const DEFAULT_PROTEIN_PCT = 0.3;
const DEFAULT_FAT_PCT = 0.3;
const WATER_LITRES_PER_KG = 0.07;
const FIBRE_G_PER_1000_KCAL = 14;
const WEIGHT_MIN_KG = 30;
const WEIGHT_MAX_KG = 300;
const LB_PER_KG = 0.453592;

const ACTIVITY_MULTIPLIERS: Record<string, number> = {
  sedentary: 1.42,
  light: 1.45,
  moderate: 1.55,
  active: 1.8,
  very_active: 1.8,
};

// Simple, deterministic meal-slot split (foodDR's is AI-assisted; this is the
// fixed-percentage equivalent, matching the fields meal_schedule_json expects).
const MEAL_SLOT_SPLIT: { meal_type: string; scheduled_time: string; pct: number }[] = [
  { meal_type: "BREAKFAST", scheduled_time: "08:00", pct: 0.25 },
  { meal_type: "LUNCH", scheduled_time: "13:00", pct: 0.35 },
  { meal_type: "EVENING_SNACK", scheduled_time: "17:00", pct: 0.1 },
  { meal_type: "DINNER", scheduled_time: "20:00", pct: 0.3 },
];

function toCm(height: string, unit: string): number {
  const value = Number(height);
  if (!Number.isFinite(value) || value <= 0) {
    throw new AppError("height must be a positive number", [], 400);
  }
  return unit === "FT" ? Math.round(value * 30.48) : Math.round(value);
}

function toKg(weight: string, unit: string): number {
  const value = Number(weight);
  if (!Number.isFinite(value) || value <= 0) {
    throw new AppError("weight must be a positive number", [], 400);
  }
  return unit === "LB" ? Number((value * LB_PER_KG).toFixed(1)) : Number(value.toFixed(1));
}

function calculateBmr(weightKg: number, heightCm: number, age: number, gender: string): number {
  // Mifflin-St Jeor.
  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;
  if (gender === "MALE") return base + 5;
  if (gender === "FEMALE") return base - 161;
  return base - 78; // OTHER — midpoint of the male/female offset
}

function calorieFloor(gender: string): number {
  return gender === "FEMALE" ? CALORIE_FLOOR_FEMALE : CALORIE_FLOOR_MALE;
}

function goalAdjustedCalories(tdee: number, primaryGoal: string | null | undefined): number {
  if (primaryGoal === "WEIGHT_LOSS") return tdee - 400;
  if (primaryGoal === "MUSCLE_GAIN") return tdee + 400;
  return tdee;
}

// user_nutrition_profiles.goal_type is a required, short lowercase code
// (confirmed against a real profile via prod's GET /auth/me: "loss" for a
// WEIGHT_LOSS user). The request interface only collects primary_goal (the
// richer, uppercase enum used elsewhere in this file's math), so goal_type
// is derived from it rather than collected twice.
function goalTypeFrom(primaryGoal: string | null | undefined): string {
  if (primaryGoal === "WEIGHT_LOSS") return "loss";
  if (primaryGoal === "MUSCLE_GAIN") return "gain";
  return "maintain";
}

function kgToLb(kg: number | null | undefined): number | null {
  return kg == null ? null : Number((Number(kg) * LB_PER_KG).toFixed(1));
}

function todayInTz(tz: string): string {
  return momentTZ.tz(tz).format("YYYY-MM-DD");
}

class NutritionControllerService {
  // ── 1. Generate Personalized Nutrition Plan ─────────────────────────────
  async generatePlan(userId: string, orgId: number | null, body: NutritionProfileReq) {
    const heightCm = toCm(body.height, body.height_unit);
    const weightKg = toKg(body.weight, body.weight_unit);
    const age = body.age;
    const gender = body.gender;

    const activityKey = String(body.activity_level || "moderate").toLowerCase();
    const activityMultiplier = ACTIVITY_MULTIPLIERS[activityKey] ?? ACTIVITY_MULTIPLIERS.moderate;

    const bmr = Math.round(calculateBmr(weightKg, heightCm, age, gender));
    const tdee = Math.round(bmr * activityMultiplier);
    const adjustedCalories = goalAdjustedCalories(tdee, body.primary_goal);
    const calorieTarget = Math.max(calorieFloor(gender), adjustedCalories);

    const proteinTargetG = Math.round((calorieTarget * DEFAULT_PROTEIN_PCT) / 4);
    const carbsTargetG = Math.round((calorieTarget * DEFAULT_CARBS_PCT) / 4);
    const fatTargetG = Math.round((calorieTarget * DEFAULT_FAT_PCT) / 9);
    const fibreTargetG = Math.round((calorieTarget / 1000) * FIBRE_G_PER_1000_KCAL);
    const waterTargetL = Number((weightKg * WATER_LITRES_PER_KG).toFixed(2));
    const waterTargetMl = Math.round(waterTargetL * 1000);

    const birthYear = new Date().getUTCFullYear() - age;
    const goalType = goalTypeFrom(body.primary_goal);

    const profileData = {
      birth_year: birthYear,
      gender,
      height_cm: heightCm,
      height_unit: "cm",
      current_weight_kg: weightKg,
      current_weight_lbs: kgToLb(weightKg),
      weight_unit: "kg",
      goal_type: goalType,
      activity_level: activityKey,
      // Required, non-nullable in the real schema; this request shape has no
      // dedicated field for it, so a sensible default is used when absent
      // rather than leaving it undefined (which the DB would reject).
      dietary_preference: body.diet_type ?? "NON_VEGETARIAN",
      cuisine_preferences: JSON.stringify(body.food_preferences ? [body.food_preferences] : []),
      primary_goal: body.primary_goal ?? null,
      secondary_goal: body.secondary_goal ?? null,
      health_conditions: body.health_conditions ?? null,
      energy_level: body.energy_level ?? null,
      meals_per_day: body.meals_per_day ?? null,
      water_intake: body.water_intake ? Number(body.water_intake) : null,
      water_intake_unit: body.water_intake_unit ?? null,
      bmr,
      tdee,
      org_id: orgId,
    };

    // One row per user, keyed by the real primary key (id === userId).
    const profile = await prisma.user_nutrition_profiles.upsert({
      where: { id: userId },
      update: profileData,
      create: { id: userId, created_by: userId, ...profileData },
    });

    const mealSlots = MEAL_SLOT_SPLIT.map((slot) => ({
      meal_type: slot.meal_type,
      scheduled_time: slot.scheduled_time,
      title: slot.meal_type.replace("_", " "),
      calories: Math.round(calorieTarget * slot.pct),
      protein_g: Math.round(proteinTargetG * slot.pct),
      carbs_g: Math.round(carbsTargetG * slot.pct),
      fat_g: Math.round(fatTargetG * slot.pct),
      fibre_g: Math.round(fibreTargetG * slot.pct),
    }));
    const mealScheduleJson = JSON.stringify(mealSlots);

    // No unique constraint on user_nutrition_plans.user_id alone (unlike the
    // profile table), so "one active plan per user" is enforced here rather
    // than via Prisma upsert: find the current active plan and update it in
    // place, or create version 1 if none exists yet.
    const existingPlan = await prisma.user_nutrition_plans.findFirst({
      where: { user_id: userId, is_active: true, is_deleted: false },
      orderBy: { version: "desc" },
    });

    const planData = {
      calorie_target: calorieTarget,
      protein_target_g: proteinTargetG,
      carbs_target_g: carbsTargetG,
      fat_target_g: fatTargetG,
      fibre_target_g: fibreTargetG,
      water_target_ml: waterTargetMl,
      meal_schedule_json: mealScheduleJson,
    };

    if (existingPlan) {
      await prisma.user_nutrition_plans.update({
        where: { id: existingPlan.id },
        data: planData,
      });
    } else {
      await prisma.user_nutrition_plans.create({
        data: {
          id: randomUUID(),
          user_id: userId,
          org_id: orgId,
          user_nutrition_profiles_id: profile.id,
          created_by: userId,
          ...planData,
        },
      });
    }

    return {
      bmr,
      tdee,
      daily_targets: {
        calories: calorieTarget,
        protein_g: proteinTargetG,
        carbs_g: carbsTargetG,
        fat_g: fatTargetG,
        fibre_g: fibreTargetG,
        water_litres: waterTargetL,
      },
      meal_schedule: mealSlots,
    };
  }

  // ── 2. Weight History (?page=1&limit=10) ────────────────────────────────
  // Real weight history is one row per user per day in `daily_stats`
  // (weight_kg/weight_lbs/weight_logged_at), not a dedicated weight_logs
  // table — see this file's header comment.
  async getWeightHistory(userId: string, query: GetWeightHistoryReq) {
    const limit = Math.min(50, Math.max(1, Number(query.limit) || 10));
    const page = Math.max(1, Number(query.page) || 1);

    const where = { user_id: userId, is_deleted: false, weight_kg: { not: null } };
    const [rows, total] = await Promise.all([
      prisma.daily_stats.findMany({
        where,
        orderBy: { date: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.daily_stats.count({ where }),
    ]);

    let currentWeight: number | null = rows[0]?.weight_kg != null ? Number(rows[0].weight_kg) : null;
    let currentWeightUnit = "KG";
    if (currentWeight === null) {
      // No logged entries yet — fall back to the profile's stored current weight.
      const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
      currentWeight = profile?.current_weight_kg != null ? Number(profile.current_weight_kg) : 0;
      currentWeightUnit = (profile?.weight_unit ?? "kg").toUpperCase();
    }

    const totalPages = Math.max(1, Math.ceil(total / limit));
    return {
      current_weight: currentWeight,
      weight_unit: currentWeightUnit,
      history: rows.map((r) => ({
        id: `w_${r.id}`,
        date: momentTZ(r.date).format("YYYY-MM-DD"),
        weight: Number(r.weight_kg),
        weight_unit: "KG",
      })),
      page,
      limit,
      total,
      total_pages: totalPages,
      current_page: page,
    };
  }

  // ── 3. Nutrition Timeline By Date (?date=YYYY-MM-DD&page=1&limit=30) ────
  // Real meal logs live in `meals`, not a `meal_logs` table.
  async getTimeline(userId: string, query: GetNutritionTimelineReq) {
    if (!query.date) {
      throw new AppError(ERROR_MESSAGE.DATE_REQUIRED, [], 400);
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(query.date)) {
      throw new AppError(ERROR_MESSAGE.INVALID_DATE_FORMAT, [], 400);
    }

    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    const tz = profile?.timezone || "Asia/Kolkata";
    const date = query.date;

    const limit = Math.min(50, Math.max(1, Number(query.limit) || 30));
    const page = Math.max(1, Number(query.page) || 1);

    const dayStart = momentTZ.tz(date, "YYYY-MM-DD", tz).startOf("day").toDate();
    const dayEnd = momentTZ.tz(date, "YYYY-MM-DD", tz).endOf("day").toDate();

    const where = {
      user_id: userId,
      is_deleted: false,
      logged_at: { gte: dayStart, lte: dayEnd },
    };

    const [meals, total] = await Promise.all([
      prisma.meals.findMany({
        where,
        orderBy: { logged_at: "desc" },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.meals.count({ where }),
    ]);

    const items = meals.map((m, i) => ({
      id: (page - 1) * limit + i + 1,
      title: m.meal_type.charAt(0) + m.meal_type.slice(1).toLowerCase().replace("_", " "),
      subtitle: m.meal_name ?? m.meal_type,
      time: momentTZ(m.logged_at).tz(tz).format("HH:mm"),
      date,
      calories: Math.round(Number(m.calories)),
      unit: "kcal",
    }));

    return {
      date,
      items,
      page,
      limit,
      total,
      total_pages: Math.max(1, Math.ceil(total / limit)),
      current_page: page,
    };
  }

  // ── Current user profile (GET /auth/me) ──────────────────────────────────
  // user_nutrition_profiles carries the full profile directly — no separate
  // `users` table and no guessed field mapping needed, unlike the earlier
  // attempt against the fictional schema (see nutritionController.ts's git
  // history / the prod-vs-local comparison report for that story).
  async getCurrentUser(userId: string) {
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    if (!profile) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PROFILE_NOT_FOUND, [], 404);
    }
    return {
      id: profile.id,
      name: profile.name ?? null,
      birth_year: profile.birth_year ?? null,
      gender: profile.gender ?? null,
      goal_type: profile.goal_type ?? null,
      current_weight_kg: profile.current_weight_kg != null ? Number(profile.current_weight_kg) : null,
      goal_weight_kg: profile.goal_weight_kg != null ? Number(profile.goal_weight_kg) : null,
      height_cm: profile.height_cm != null ? Number(profile.height_cm) : null,
      activity_level: profile.activity_level ?? null,
      timezone: profile.timezone ?? "Asia/Kolkata",
      weight_unit: profile.weight_unit ?? "kg",
    };
  }

  // ── Update Weight (range 30–300 kg) ──────────────────────────────────────
  // A deliberately simplified real implementation: it validates and persists
  // for real (profile + today's daily_stats row), but does not replicate
  // prod's progressive change-tolerance window or automatic plan
  // recalculation on weight change (nutritionClientV2WeightService.ts in
  // backend-node) — that's meaningfully more business logic (unit-aware
  // tolerance bands, re-deriving and rewriting plan targets) than a
  // controller/schema fix should silently invent.
  async updateWeight(userId: string, body: JsonRecord) {
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    if (!profile) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PROFILE_NOT_FOUND, [], 404);
    }

    const unit = typeof body.weight_unit === "string" ? body.weight_unit.toUpperCase() : (profile.weight_unit ?? "kg").toUpperCase();
    const rawValue = Number(body.weight ?? body.weight_kg ?? body.weight_lb);
    if (!Number.isFinite(rawValue) || rawValue <= 0) {
      throw new AppError("weight must be a positive number", [], 400);
    }
    const weightKg = unit === "LB" ? Number((rawValue * LB_PER_KG).toFixed(1)) : Number(rawValue.toFixed(1));
    if (weightKg < WEIGHT_MIN_KG || weightKg > WEIGHT_MAX_KG) {
      throw new AppError(`weight must be between ${WEIGHT_MIN_KG} and ${WEIGHT_MAX_KG} kg`, [], 400);
    }
    const weightLbs = kgToLb(weightKg);

    const today = todayInTz(profile.timezone || "Asia/Kolkata");
    const todayDate = momentTZ.tz(today, "YYYY-MM-DD", "UTC").toDate();

    await prisma.user_nutrition_profiles.update({
      where: { id: userId },
      data: {
        current_weight_kg: weightKg,
        current_weight_lbs: weightLbs,
        last_weight_update_date: todayDate,
      },
    });

    await prisma.daily_stats.upsert({
      where: { user_id_date: { user_id: userId, date: todayDate } },
      update: { weight_kg: weightKg, weight_lbs: weightLbs, weight_logged_at: new Date() },
      create: {
        id: randomUUID(),
        user_id: userId,
        date: todayDate,
        weight_kg: weightKg,
        weight_lbs: weightLbs,
        weight_logged_at: new Date(),
      },
    });

    return {
      current_weight: weightKg,
      current_weight_lbs: weightLbs,
      weight_unit: profile.weight_unit ?? "kg",
      updated_at: today,
    };
  }

  // ── Nutrition Dashboard (today's plan + stats + meals) ──────────────────
  async getNutritionSummaryByDate(userId: string, query: JsonRecord) {
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    if (!profile) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PROFILE_NOT_FOUND, [], 404);
    }
    const tz = profile.timezone || "Asia/Kolkata";
    const date = typeof query.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(query.date) ? query.date : todayInTz(tz);
    const dateObj = momentTZ.tz(date, "YYYY-MM-DD", "UTC").toDate();

    const plan = await prisma.user_nutrition_plans.findFirst({
      where: { user_id: userId, is_active: true, is_deleted: false },
      orderBy: { version: "desc" },
    });
    if (!plan) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PLAN_NOT_FOUND, [], 404);
    }

    const dayStart = momentTZ.tz(date, "YYYY-MM-DD", tz).startOf("day").toDate();
    const dayEnd = momentTZ.tz(date, "YYYY-MM-DD", tz).endOf("day").toDate();
    const [stats, meals] = await Promise.all([
      prisma.daily_stats.findUnique({ where: { user_id_date: { user_id: userId, date: dateObj } } }),
      prisma.meals.findMany({
        where: { user_id: userId, is_deleted: false, logged_at: { gte: dayStart, lte: dayEnd } },
        orderBy: { logged_at: "asc" },
      }),
    ]);

    const caloriesConsumed = stats ? Number(stats.calories_consumed) : 0;
    return {
      date,
      nutrition_goals: {
        calorie_target: plan.calorie_target,
        protein_target_g: plan.protein_target_g,
        carbs_target_g: plan.carbs_target_g,
        fat_target_g: plan.fat_target_g,
        fibre_target_g: plan.fibre_target_g ?? null,
        water_target_ml: plan.water_target_ml ?? null,
      },
      summary: {
        calories_consumed: caloriesConsumed,
        calories_remaining: Math.max(0, plan.calorie_target - caloriesConsumed),
        protein_consumed_g: stats ? Number(stats.protein_consumed_g) : 0,
        carbs_consumed_g: stats ? Number(stats.carbs_consumed_g) : 0,
        fat_consumed_g: stats ? Number(stats.fat_consumed_g) : 0,
        fibre_consumed_g: stats ? Number(stats.fibre_consumed_g) : 0,
        water_consumed_ml: stats ? stats.water_consumed_ml : 0,
        meal_count: meals.length,
      },
      logged_meals: meals.map((m) => ({
        id: m.id,
        meal_type: m.meal_type,
        meal_name: m.meal_name ?? null,
        calories: Math.round(Number(m.calories)),
        protein_g: Number(m.protein_g),
        carbs_g: Number(m.carbs_g),
        fat_g: Number(m.fat_g),
        logged_at: m.logged_at,
      })),
    };
  }

  // ── Progress By Date ──────────────────────────────────────────────────────
  async getProgressByDate(userId: string, query: JsonRecord) {
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    if (!profile) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PROFILE_NOT_FOUND, [], 404);
    }
    const tz = profile.timezone || "Asia/Kolkata";
    const date = typeof query.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(query.date) ? query.date : todayInTz(tz);
    const dateObj = momentTZ.tz(date, "YYYY-MM-DD", "UTC").toDate();

    const plan = await prisma.user_nutrition_plans.findFirst({
      where: { user_id: userId, is_active: true, is_deleted: false },
      orderBy: { version: "desc" },
    });
    const stats = await prisma.daily_stats.findUnique({ where: { user_id_date: { user_id: userId, date: dateObj } } });

    const goalCalories = plan?.calorie_target ?? null;
    const consumedCalories = stats ? Number(stats.calories_consumed) : 0;

    return {
      date,
      goal: {
        calorie_target: goalCalories,
        protein_target_g: plan?.protein_target_g ?? null,
        carbs_target_g: plan?.carbs_target_g ?? null,
        fat_target_g: plan?.fat_target_g ?? null,
      },
      progress: {
        calories_consumed: consumedCalories,
        calories_remaining: goalCalories != null ? Math.max(0, goalCalories - consumedCalories) : null,
        percent_of_goal: goalCalories ? Math.round((consumedCalories / goalCalories) * 100) : null,
        adherence_status: stats?.adherence_status ?? null,
        streak_day: stats?.streak_day ?? 0,
      },
    };
  }

  // ── Nutrition Health Score ────────────────────────────────────────────────
  // daily_stats already carries precomputed health_score/score_breakdown_json
  // columns (the real backend-node's scoring service writes them) — this
  // reads them rather than recomputing an independent scoring algorithm,
  // which would be guessing at business rules this checkout doesn't own.
  async getHealthScore(userId: string, query: JsonRecord) {
    const days = Math.min(90, Math.max(1, Number(query.range) || 7));
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    if (!profile) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PROFILE_NOT_FOUND, [], 404);
    }
    const tz = profile.timezone || "Asia/Kolkata";
    const today = todayInTz(tz);
    const since = momentTZ.tz(today, "YYYY-MM-DD", "UTC").subtract(days - 1, "days").toDate();

    const rows = await prisma.daily_stats.findMany({
      where: { user_id: userId, is_deleted: false, date: { gte: since } },
      orderBy: { date: "asc" },
    });

    const latest = rows[rows.length - 1];
    let breakdown: JsonRecord | null = null;
    if (latest?.score_breakdown_json) {
      try {
        breakdown = JSON.parse(latest.score_breakdown_json) as JsonRecord;
      } catch {
        breakdown = null;
      }
    }

    return {
      range_days: days,
      health_score: latest?.health_score != null ? Number(latest.health_score) : null,
      score_breakdown: breakdown,
      chart: rows.map((r) => ({
        date: momentTZ(r.date).format("YYYY-MM-DD"),
        health_score: r.health_score != null ? Number(r.health_score) : null,
      })),
    };
  }

  // ── Nutrition Achievements ────────────────────────────────────────────────
  async getAchievements(userId: string) {
    const rows = await prisma.achievements.findMany({
      where: { user_id: userId, is_deleted: false },
      orderBy: { unlocked_at: "desc" },
    });
    return {
      total: rows.length,
      achievements: rows.map((a) => {
        let payload: JsonRecord | null = null;
        try {
          payload = JSON.parse(a.payload) as JsonRecord;
        } catch {
          payload = null;
        }
        return {
          id: a.id,
          type: a.achievement_type,
          unlocked_at: a.unlocked_at,
          celebrated: a.celebrated,
          ...(payload ?? {}),
        };
      }),
    };
  }

  // ── Upcoming Routine ───────────────────────────────────────────────────────
  // Read-only: returns the most recent stored `routines` row if one exists.
  // Prod generates this via an AI call (see backend-node's
  // nutritionClientV2RoutineService.ts); this checkout has no Gemini wiring
  // in this controller, so it deliberately does not generate a new one —
  // fabricating "AI routine content" would be exactly the kind of guessing
  // this checkout's own CLAUDE.md says not to do.
  async getUpcomingRoutine(userId: string, query: JsonRecord) {
    const days = Math.min(30, Math.max(1, Number(query.days) || 7));
    const routine = await prisma.routines.findFirst({
      where: { user_id: userId, is_deleted: false },
      orderBy: { generated_date: "desc" },
    });
    if (!routine) {
      throw new AppError(
        "No routine has been generated for this user yet. Routine generation is AI-driven and not implemented in this partial checkout.",
        [],
        404,
      );
    }
    let daysJson: unknown = [];
    try {
      daysJson = JSON.parse(routine.days_json);
    } catch {
      daysJson = [];
    }
    return {
      requested_days: days,
      generated_date: momentTZ(routine.generated_date).format("YYYY-MM-DD"),
      start_date: momentTZ(routine.start_date).format("YYYY-MM-DD"),
      end_date: momentTZ(routine.end_date).format("YYYY-MM-DD"),
      weekly_tip: routine.weekly_tip ?? null,
      motivation: routine.motivation ?? null,
      days: daysJson,
    };
  }

  // ── Goal Progress report ───────────────────────────────────────────────────
  async getGoalProgress(userId: string, query: JsonRecord) {
    const days = Math.min(90, Math.max(1, Number(query.days) || 7));
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    if (!profile) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PROFILE_NOT_FOUND, [], 404);
    }
    const tz = profile.timezone || "Asia/Kolkata";
    const today = todayInTz(tz);
    const since = momentTZ.tz(today, "YYYY-MM-DD", "UTC").subtract(days - 1, "days").toDate();

    const plan = await prisma.user_nutrition_plans.findFirst({
      where: { user_id: userId, is_active: true, is_deleted: false },
      orderBy: { version: "desc" },
    });
    const rows = await prisma.daily_stats.findMany({
      where: { user_id: userId, is_deleted: false, date: { gte: since } },
      orderBy: { date: "asc" },
    });

    const onTrackDays = rows.filter((r) => r.adherence_status === "on_track").length;
    return {
      selected_days: days,
      goal_calories: plan?.calorie_target ?? null,
      progress: {
        days_logged: rows.length,
        on_track_days: onTrackDays,
        adherence_rate: rows.length ? Math.round((onTrackDays / rows.length) * 100) : null,
        current_weight_kg: profile.current_weight_kg != null ? Number(profile.current_weight_kg) : null,
        goal_weight_kg: profile.goal_weight_kg != null ? Number(profile.goal_weight_kg) : null,
      },
    };
  }

  // ── Meals by type (food_catalog, no AI matching) ─────────────────────────
  async getMealsByType(query: JsonRecord) {
    const mealType = typeof query.meal_type === "string" ? query.meal_type.toLowerCase() : undefined;
    const limit = Math.min(50, Math.max(1, Number(query.limit) || 10));
    const page = Math.max(1, Number(query.page) || 1);
    const where = { is_deleted: false, ...(mealType ? { meal_type: mealType } : {}) };

    const [rows, total] = await Promise.all([
      prisma.food_catalog.findMany({ where, skip: (page - 1) * limit, take: limit, orderBy: { name: "asc" } }),
      prisma.food_catalog.count({ where }),
    ]);

    return {
      recommended_meals: rows.map((r) => this.mapFoodCatalogRow(r)),
      total_pages: Math.max(1, Math.ceil(total / limit)),
      current_page: page,
    };
  }

  // ── Meal search / autocomplete ────────────────────────────────────────────
  async searchMeals(query: JsonRecord) {
    const term = typeof query.query === "string" ? query.query.trim() : "";
    const limit = Math.min(50, Math.max(1, Number(query.limit) || 10));
    if (!term) return [];
    const rows = await prisma.food_catalog.findMany({
      where: {
        is_deleted: false,
        OR: [{ name: { contains: term } }, { display_name: { contains: term } }],
      },
      take: limit,
      orderBy: { name: "asc" },
    });
    return rows.map((r) => this.mapFoodCatalogRow(r));
  }

  private mapFoodCatalogRow(r: { id: string; name: string; display_name: string; meal_type: string | null; calories: number; protein_g: number; carbs_g: number; fat_g: number; fibre_g: number; serving_unit: string }) {
    return {
      id: r.id,
      name: r.name,
      display_name: r.display_name,
      meal_type: r.meal_type,
      calories: r.calories,
      protein_g: r.protein_g,
      carbs_g: r.carbs_g,
      fat_g: r.fat_g,
      fibre_g: r.fibre_g,
      serving_unit: r.serving_unit,
    };
  }

  // ── Logged meals by date (V1) ─────────────────────────────────────────────
  async loggedMealsByDate(userId: string, query: JsonRecord) {
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    const tz = profile?.timezone || "Asia/Kolkata";
    const date = typeof query.date === "string" && /^\d{4}-\d{2}-\d{2}$/.test(query.date) ? query.date : todayInTz(tz);
    const limit = Math.min(50, Math.max(1, Number(query.limit) || 10));
    const page = Math.max(1, Number(query.page) || 1);

    const dayStart = momentTZ.tz(date, "YYYY-MM-DD", tz).startOf("day").toDate();
    const dayEnd = momentTZ.tz(date, "YYYY-MM-DD", tz).endOf("day").toDate();
    const where = { user_id: userId, is_deleted: false, logged_at: { gte: dayStart, lte: dayEnd } };

    const [meals, total] = await Promise.all([
      prisma.meals.findMany({ where, orderBy: { logged_at: "desc" }, skip: (page - 1) * limit, take: limit }),
      prisma.meals.count({ where }),
    ]);

    return {
      logged_meals: meals.map((m) => ({
        id: m.id,
        meal_type: m.meal_type,
        meal_name: m.meal_name ?? null,
        calories: Math.round(Number(m.calories)),
        protein_g: Number(m.protein_g),
        carbs_g: Number(m.carbs_g),
        fat_g: Number(m.fat_g),
        logged_at: m.logged_at,
        thumbnail_url: m.photo_url ?? null,
      })),
      total_pages: Math.max(1, Math.ceil(total / limit)),
      current_page: page,
    };
  }

  // ── Delete meal (soft delete, ownership-checked) ─────────────────────────
  async deleteMeal(userId: string, mealId: string) {
    const meal = await prisma.meals.findUnique({ where: { id: mealId } });
    if (!meal || meal.is_deleted || meal.user_id !== userId) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PLAN_NOT_FOUND, [], 404);
    }
    await prisma.meals.update({ where: { id: mealId }, data: { is_deleted: true } });
    return { deleted: true, id: mealId };
  }

  // ── Add meal (manual entry — no AI photo classification) ────────────────
  // A real write against the `meals` table for a directly-supplied
  // type/macro entry. Prod's equivalent also accepts a photo and runs it
  // through Gemini for classification; that path isn't wired into this
  // checkout (no vision-model integration here), so this only supports the
  // manual/macros-supplied case rather than faking a recognition result.
  async addMeal(userId: string, orgId: number | null, body: JsonRecord) {
    const mealType = typeof body.meal_type === "string" ? body.meal_type.toUpperCase() : undefined;
    const calories = Number(body.calories);
    if (!mealType || !Number.isFinite(calories) || calories <= 0) {
      throw new AppError("meal_type and a positive calories value are required", [], 400);
    }
    const now = new Date();
    const meal = await prisma.meals.create({
      data: {
        id: randomUUID(),
        user_id: userId,
        org_id: orgId,
        meal_type: mealType,
        logged_at: now,
        logged_date: now,
        calories,
        protein_g: Number(body.protein_g) || 0,
        carbs_g: Number(body.carbs_g) || 0,
        fat_g: Number(body.fat_g) || 0,
        fibre_g: Number(body.fibre_g) || 0,
        meal_name: typeof body.meal_name === "string" ? body.meal_name : null,
        source: "manual",
        is_verified: true,
      },
    });
    return { id: meal.id, meal_type: meal.meal_type, calories: Number(meal.calories), logged_at: meal.logged_at };
  }

  // ── Update water consumption (V1) ────────────────────────────────────────
  async updateWaterConsumption(userId: string, body: JsonRecord) {
    const profile = await prisma.user_nutrition_profiles.findUnique({ where: { id: userId } });
    if (!profile) {
      throw new AppError(ERROR_MESSAGE.NUTRITION_PROFILE_NOT_FOUND, [], 404);
    }
    const amountMl = Number(body.amount_ml ?? body.water_ml ?? body.amount);
    if (!Number.isFinite(amountMl) || amountMl <= 0) {
      throw new AppError("a positive amount_ml is required", [], 400);
    }
    const today = todayInTz(profile.timezone || "Asia/Kolkata");
    const todayDate = momentTZ.tz(today, "YYYY-MM-DD", "UTC").toDate();

    const existing = await prisma.daily_stats.findUnique({ where: { user_id_date: { user_id: userId, date: todayDate } } });
    const newTotal = (existing?.water_consumed_ml ?? 0) + Math.round(amountMl);

    await prisma.daily_stats.upsert({
      where: { user_id_date: { user_id: userId, date: todayDate } },
      update: { water_consumed_ml: newTotal, water_logged_at: new Date() },
      create: { id: randomUUID(), user_id: userId, date: todayDate, water_consumed_ml: newTotal, water_logged_at: new Date() },
    });

    return { water_consumed_ml: newTotal, date: today };
  }

  // ── Complete assessment (V1) ─────────────────────────────────────────────
  async completeAssessment(userId: string) {
    const profile = await prisma.user_nutrition_profiles.update({
      where: { id: userId },
      data: { onboarding_completed: true },
    });
    return { onboarding_completed: profile.onboarding_completed };
  }
}

export default new NutritionControllerService();
